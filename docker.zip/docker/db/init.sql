create database devops;
use devops;

CREATE TABLE test_table (
  name VARCHAR(20),
  age INT(10)
);

INSERT INTO test_table
  (name, age)
VALUES
  ('Oskar', '35');
